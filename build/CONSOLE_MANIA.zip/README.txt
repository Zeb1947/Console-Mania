CONSOLE MANIA™
BY DEAN BROSNAN

UNLICENSED SOFTWARE
[current version: b0.1]

This game is provided “as-is” without any license or warranty.

You may use and play this software for personal, non-commercial purposes only.

Please respect the author’s rights and do not redistribute, modify, or claim ownership of this game without permission.

By using this software, you agree not to dispute the author’s rights or misuse the software in any way.

Thank you for respecting this work.

